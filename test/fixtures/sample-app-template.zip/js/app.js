
(function() {
  console.log("This is some javascript");
})();
